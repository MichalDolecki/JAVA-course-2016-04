package logika;

/**
 *
 * @author Student
 */
public class KlasySettings {
    public static double dostepnaSiatka = 55;
    /**
     * Liczba losowań w metodach MonteCarlo;
     */
    public static int liczbaLosowan = 10000;
}
