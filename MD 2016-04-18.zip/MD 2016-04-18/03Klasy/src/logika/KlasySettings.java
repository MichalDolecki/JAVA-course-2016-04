package logika;

/**
 *
 * @author Student
 */
public class KlasySettings {
    public static double dostepnaSiatka = 55;
}
