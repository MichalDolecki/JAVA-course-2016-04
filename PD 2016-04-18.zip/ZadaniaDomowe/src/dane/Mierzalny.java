package dane;

/**
 *
 * @author Student
 */
public interface Mierzalny {
    double length();
}
