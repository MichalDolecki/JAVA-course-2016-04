package logic;

/**
 *
 * @author Michał Dolecki <michal.dolecki@kul.pl>
 */
public class Main {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {

  }

}
